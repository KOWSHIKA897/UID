import React from 'react';
import './About.css';

const About = () => {
  return (
    <section id="about" className="about-section">
      <h2>About Us</h2>
      <p>We are a company specializing in [services]. Our mission is to deliver quality solutions to our clients.</p>
    </section>
  );
}

export default About;
