import React, { useState } from 'react';

const Counter = () => {
    const [count, setCount] = useState(0);
    const [inputValue, setInputValue] = useState(1); // Default increment/decrement value

    const handleIncrement = () => {
        setCount(count + Number(inputValue));
    };

    const handleDecrement = () => {
        setCount(count - Number(inputValue));
    };

    const handleInputChange = (event) => {
        setInputValue(event.target.value);
    };

    return (
        <div style={{ textAlign: 'center', marginTop: '50px' }}>
            <h1>Counter: {count}</h1>
            <input 
                type="number" 
                value={inputValue} 
                onChange={handleInputChange} 
                style={{ margin: '10px', width: '50px' }} 
            />
            <br />
            <button onClick={handleIncrement} style={{ margin: '5px' }}>
                Increment
            </button>
            <button onClick={handleDecrement} style={{ margin: '5px' }}>
                Decrement
            </button>
        </div>
    );
};

export default Counter;
