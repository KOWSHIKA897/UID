import React, { useState } from 'react';
import './Calculator.css';

const Calculator = () => {
  const [input, setInput] = useState(''); // Holds current input
  const [result, setResult] = useState(''); // Holds the result after evaluation

  // Function to handle button clicks
  const handleClick = (value) => {
    setInput((prev) => prev + value); // Append value to input
  };

  // Function to clear input and result
  const handleClear = () => {
    setInput('');
    setResult('');
  };

  // Function to calculate the result
  const handleEqual = () => {
    try {
      // Evaluate the expression (use with caution)
      setResult(eval(input).toString()); 
    } catch (error) {
      setResult('Error'); // Show error if invalid input
    }
  };

  // Function to calculate square root
  const handleSqrt = () => {
    try {
      const sqrtResult = Math.sqrt(eval(input)).toString();
      setResult(sqrtResult);
      setInput(''); // Clear input after showing result
    } catch (error) {
      setResult('Error'); // Show error if invalid input
    }
  };

  // Function to square a number
  const handleSquare = () => {
    try {
      const squareResult = Math.pow(eval(input), 2).toString();
      setResult(squareResult);
      setInput(''); // Clear input after showing result
    } catch (error) {
      setResult('Error'); // Show error if invalid input
    }
  };

  return (
    <div className="calculator-container">
      <div className="display">
        <p className="input">{input || '0'}</p>
        <p className="result">{result ? `= ${result}` : ''}</p>
      </div>
      <div className="buttons">
        <button onClick={handleClear} className="clear">C</button>
        <button onClick={() => handleClick('7')}>7</button>
        <button onClick={() => handleClick('8')}>8</button>
        <button onClick={() => handleClick('9')}>9</button>
        <button onClick={() => handleClick('/')}>/</button>
        
        <button onClick={() => handleClick('4')}>4</button>
        <button onClick={() => handleClick('5')}>5</button>
        <button onClick={() => handleClick('6')}>6</button>
        <button onClick={() => handleClick('*')}>*</button>
        
        <button onClick={() => handleClick('1')}>1</button>
        <button onClick={() => handleClick('2')}>2</button>
        <button onClick={() => handleClick('3')}>3</button>
        <button onClick={() => handleClick('-')}>-</button>
        
        <button onClick={() => handleClick('0')}>0</button>
        <button onClick={() => handleClick('.')}>.</button>
        <button onClick={handleEqual} className="equal">=</button>
        <button onClick={() => handleClick('+')}>+</button>

        {/* Additional buttons for sqrt and square */}
        <button onClick={handleSqrt} className="sqrt">√</button>
        <button onClick={handleSquare} className="square">x²</button>
      </div>
    </div>
  );
};

export default Calculator;
