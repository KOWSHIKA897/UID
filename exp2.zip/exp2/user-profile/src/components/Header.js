import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Header.css';

const Header = ({ user, setUser }) => {
  const navigate = useNavigate();

  // Logout function
  const handleLogout = () => {
    setUser(null); // Clear the user state
    navigate('/'); // Navigate to home
  };

  return (
    <header className="header">
      <h1 className="logo">User Profile App</h1>
      <nav>
        <ul>
          {!user ? (
            // Show 'Create Account' button if no user is logged in
            <li><Link to="/create-account">Create Account</Link></li>
          ) : (
            // Show 'Logout' button if user is logged in
            <>
              <li><Link to="/profile">Profile</Link></li>
              <li><button onClick={handleLogout} className="logout-button">Logout</button></li>
            </>
          )}
        </ul>
      </nav>
    </header>
  );
};

export default Header;
