import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './CreateAccount.css';  // Reuse CreateAccount styles

const EditProfile = ({ user, setUser }) => {
  const [formData, setFormData] = useState({
    name: user.name,
    age: user.age,
    bio: user.bio,
    location: user.location,
    avatar: user.avatar
  });
  const [previewImage, setPreviewImage] = useState(user.avatar); // For displaying image preview
  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle file input for avatar
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, avatar: reader.result });
        setPreviewImage(reader.result); // Show preview of uploaded image
      };
      reader.readAsDataURL(file); // Convert image to base64
    }
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    setUser({
      ...formData
    });
    navigate('/profile');  // Redirect back to profile page
  };

  return (
    <div className="create-account-container">
      <h2>Edit Profile</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Name"
          value={formData.name}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="age"
          placeholder="Age"
          value={formData.age}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="location"
          placeholder="Location"
          value={formData.location}
          onChange={handleChange}
          required
        />
        <textarea
          name="bio"
          placeholder="Tell us about yourself"
          value={formData.bio}
          onChange={handleChange}
          required
        ></textarea>

        {/* File input for uploading profile image */}
        <input
          type="file"
          accept="image/*"
          onChange={handleImageChange}
        />

        {/* Display image preview */}
        {previewImage && (
          <img
            src={previewImage}
            alt="Profile Preview"
            className="profile-image-preview"
          />
        )}

        <button type="submit">Save Changes</button>
      </form>
    </div>
  );
};

export default EditProfile;
