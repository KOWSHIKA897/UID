import React from 'react';
import { useNavigate } from 'react-router-dom';
import './UserProfile.css';

const UserProfile = (props) => {
  const { name, age, bio, location, avatar } = props;
  const navigate = useNavigate();

  // Navigate to edit profile page
  const handleEdit = () => {
    navigate('/edit-profile');
  };

  return (
    <div className="profile-container">
      <img src={avatar} alt={`${name}'s avatar`} className="profile-avatar" />
      <h2 className="profile-name">{name}</h2>
      <p className="profile-age">Age: {age}</p>
      <p className="profile-location">Location: {location}</p>
      <p className="profile-bio">{bio}</p>

      <button className="edit-profile-button" onClick={handleEdit}>Edit Profile</button>
    </div>
  );
};

export default UserProfile;
