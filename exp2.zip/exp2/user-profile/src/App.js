import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Header from './components/Header';
import CreateAccount from './components/CreateAccount';
import UserProfile from './components/UserProfile';
import EditProfile from './components/EditProfile';

function App() {
  const [user, setUser] = useState(null);

  return (
    <Router>
      <div className="App">
        {/* Pass user and setUser to Header */}
        <Header user={user} setUser={setUser} />
        <Routes>
          <Route path="/" element={<h1>Welcome to the User Profile App</h1>} />
          <Route path="/create-account" element={<CreateAccount setUser={setUser} />} />
          {user && <Route path="/profile" element={<UserProfile {...user} />} />}
          {user && <Route path="/edit-profile" element={<EditProfile user={user} setUser={setUser} />} />}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
