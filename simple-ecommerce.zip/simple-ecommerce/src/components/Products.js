// src/components/Products.js
import React, { useState } from 'react';

const productsData = [
  { id: 1, name: 'Apple', price: 29.99, image: '/images/apple.jpeg' },
  { id: 2, name: 'Mango', price: 19.99, image: '/images/mango.jpeg' },
  { id: 3, name: 'Pineapple', price: 24.99, image: '/images/pineapple.jpeg' },
];

const Products = ({ addToCart }) => {
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [formData, setFormData] = useState({ name: '', email: '' });

  const handlePurchase = (product) => {
    // Handle form submission for purchase
    console.log('Purchasing product:', product);
    console.log('User details:', formData);
    // Clear the form after adding to cart
    setFormData({ name: '', email: '' });
    setSelectedProduct(null); // Clear selected product
  };

  return (
    <div className="products">
      <h1>Products</h1>
      <div className="product-cards">
        {productsData.map(product => (
          <div key={product.id} className="product-card">
            <img src={product.image} alt={product.name} />
            <h2>{product.name}</h2>
            <p>Price: ${product.price.toFixed(2)}</p>
            <button onClick={() => addToCart(product)}>Add to Cart</button>
            <button onClick={() => setSelectedProduct(product)}>Buy Now</button>
          </div>
        ))}
      </div>

      {selectedProduct && (
        <div className="purchase-form">
          <h2>Purchase {selectedProduct.name}</h2>
          <form onSubmit={(e) => {
            e.preventDefault();
            handlePurchase(selectedProduct);
          }}>
            <input
              type="text"
              placeholder="Your Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
            <input
              type="email"
              placeholder="Your Email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
            <button type="submit">Confirm Purchase</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default Products;
