// src/components/Navbar.js
import React from 'react';
import { Link } from 'react-router-dom';
//import './Navbar.css'; // Optional: Add styles for the navbar

const Navbar = () => {
  return (
    <nav>
      <ul>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/products">Products</Link></li>
        <li><Link to="/cart">Cart</Link></li>
      </ul>
    </nav>
  );
};

export default Navbar;
